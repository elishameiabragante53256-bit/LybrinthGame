/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thelabyrinth;
import javax.swing.*;
import java.awt.*;

public class CharacterSelect extends JPanel {
    public CharacterSelect(GameWindow w) {
        setBackground(Color.darkGray);
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.gridy = 0;
        JLabel t = new JLabel("Select Character");
        t.setFont(new Font("SansSerif", Font.BOLD, 24));
        t.setForeground(Color.white);
        add(t, c);

        c.gridy = 1;
        JButton bw = new JButton("Warrior");
        bw.addActionListener(e -> w.startGame(Player.ClassType.WARRIOR));
        add(bw, c);

        c.gridy = 2;
        JButton br = new JButton("Rogue");
        br.addActionListener(e -> w.startGame(Player.ClassType.ROGUE));
        add(br, c);

        c.gridy = 3;
        JButton bm = new JButton("Mage");
        bm.addActionListener(e -> w.startGame(Player.ClassType.MAGE));
        add(bm, c);

        c.gridy = 4;
        JButton back = new JButton("Back");
        back.addActionListener(e -> w.showMenu());
        add(back, c);
    }
}