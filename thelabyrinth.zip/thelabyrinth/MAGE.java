/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thelabyrinth;

import java.awt.*;

public class MAGE extends Player {
    private final int baseDamage = 22;

    public MAGE(int spawnX, int spawnY, GamePanel game) {
        super(ClassType.MAGE, spawnX, spawnY, game);
        this.maxHp = 120; this.hp = maxHp;
        this.maxResource = 220; this.resource = maxResource;
        this.resourceType = ResourceType.MANA;
    }

    @Override
    public void update(boolean up, boolean down, boolean left, boolean right,
                       boolean attackKey, boolean key1, boolean key2, boolean qKey, boolean eKey, boolean rKey, MazeGenerator maze) {
        int speed = 2;
        int newX = x, newY = y;
        if (up) newY -= speed;
        if (down) newY += speed;
        if (left) newX -= speed;
        if (right) newX += speed;

        if (newX != x) facingX = Integer.signum(newX - x);
        if (newY != y) facingY = Integer.signum(newY - y);

        if (!maze.isWallAtPixel(newX + width/2, y + height/2)) x = newX;
        if (!maze.isWallAtPixel(x + width/2, newY + height/2)) y = newY;

        if (resource < maxResource) resource++;

        if (key1 && skillCooldown == 0) {
            if (resource >= 25) {
                resource -= 25;
                int sx = x + width/2 + facingX*10;
                int sy = y + height/2 + facingY*10;
                int pdx = facingX * 8;
                int pdy = facingY * 8;
                game.projectiles.add(new Projectile(this, game, baseDamage + level*2));
                game.quest.addMessage("Mage casts Fireball!");
                skillCooldown = 40;
            } else game.quest.addMessage("Not enough Mana for Fireball!");
        }

        if (key2 && skillCooldown == 0) {
            if (resource >= 25) {
                resource -= 25;
                for (Enemy e : game.enemies) {
                    if (Math.abs(e.x - x) < 120 && Math.abs(e.y - y) < 120) {
                        e.hp -= 10;
                    }
                }
                game.quest.addMessage("Mage used Ice Shard!");
                skillCooldown = 50;
            } else game.quest.addMessage("Not enough Mana for Ice Shard!");
        }

        if (attackKey && attackCooldown == 0) {
            melee();
            attackCooldown = 20;
        }
        if (attackCooldown > 0) attackCooldown--;
        if (skillCooldown > 0) skillCooldown--;
        if (potionCooldown > 0) potionCooldown--;
        if (qKey) useHealthPotion();
        if (eKey) useResourcePotion();
    }

    private void melee() {
        for (Enemy e : game.enemies) {
            int dx = Math.abs((e.x + e.width/2) - (x + width/2));
            int dy = Math.abs((e.y + e.height/2) - (y + height/2));
            if (dx <= 50 && dy <= 50) {
                e.hp -= baseDamage + level*2;
                game.quest.addMessage("Mage hits for " + (baseDamage + level*2));
            }
        }
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(new Color(60,120,200));
        g.fillRect(x, y, width, height);
    }

    @Override
    protected int getAttackCost() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    protected int getSkillCost() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}   
