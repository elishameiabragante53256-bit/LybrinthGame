/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thelabyrinth;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class FloorManager {

    public FloorManager(GamePanel aThis) {
    }

    public static class FloorDefinition {
        public String name;
        public Color floorColor;
        public Color wallColor;
        public Class<? extends Enemy> enemyType;
        public boolean isBossFloor;

        public FloorDefinition(String name, Color floorColor, Color wallColor,
                Class<? extends Enemy> enemyType, boolean isBossFloor) {
            this.name = name;
            this.floorColor = floorColor;
            this.wallColor = wallColor;
            this.enemyType = enemyType;
            this.isBossFloor = isBossFloor;
        }
    }

    // ----------- DEFINE ALL FLOORS HERE -------------
    public static List<FloorDefinition> floors = new ArrayList<>();

    static {
        floors.add(new FloorDefinition(
                "Goblin Cave",
                new Color(40, 40, 40),
                new Color(90, 90, 90),
                Goblin.class,
                false));

        floors.add(new FloorDefinition(
                "Forest Passage",
                new Color(20, 80, 20),
                new Color(70, 120, 70),
                ElfEnemy.class,
                false));

        floors.add(new FloorDefinition(
                "Ruined Temple",
                new Color(110, 90, 60),
                new Color(150, 140, 100),
                Skeleton.class,
                false));

        floors.add(new FloorDefinition(
                "Ancient Library",
                new Color(100, 50, 20),
                new Color(160, 110, 70),
                MageEnemy.class,
                false));

        floors.add(new FloorDefinition(
                "Demon Lair",
                new Color(120, 20, 20),
                new Color(180, 40, 40),
                Demon.class,
                false));

        floors.add(new FloorDefinition(    // FLOOR 6 BOSS
                "Boss Chamber",
                new Color(30, 0, 0),
                new Color(80, 0, 0),
                Boss.class,
                true));
    }

    public static FloorDefinition get(int floor) {
        if (floor <= 0) floor = 1;
        if (floor > floors.size()) floor = floors.size();
        return floors.get(floor - 1);
    }
}
