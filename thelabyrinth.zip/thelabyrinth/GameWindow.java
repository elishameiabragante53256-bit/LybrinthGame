/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thelabyrinth;

import javax.swing.*;
import java.awt.*;
public class GameWindow extends JFrame {
    private OpeningMenu menu;
    public GameWindow() {
        setTitle("The Labyrinth");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setSize(960, 720);
        setLocationRelativeTo(null);
        menu = new OpeningMenu(this);
        setContentPane(menu);
    }
    public void startGame(Player.ClassType cls) {
        GamePanel gp = new GamePanel(cls, this);
        setContentPane(gp);
        revalidate();
        gp.requestFocusInWindow();
        gp.startGame();
    }
    public void showMenu() {
        setContentPane(menu);
        revalidate();
        menu.requestFocusInWindow();
    }
}
