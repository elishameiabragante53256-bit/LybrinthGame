package thelabyrinth;

public class Utils {
    public static int clamp(int v, int a, int b) { 
        return Math.max(a, Math.min(b, v)); 
    }
}
