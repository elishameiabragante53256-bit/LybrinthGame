package GameUli;
import java.awt.*;

public class Boss extends Enemy {
    private int maxHp = 1000;
    private boolean special = false;
    private boolean deathHandled = false;  

    public Boss(int px, int py, GamePanel game) {
        super(px, py, game);
        this.hp = maxHp;
        this.width = MazeGenerator.TILE_SIZE + 8;
        this.height = MazeGenerator.TILE_SIZE + 8;
        this.moveSpeed = 2;
    }

   @Override
public void update(Player player, MazeGenerator maze) {
    // 🔥 Check for death here
    if (hp <= 0) {
        handleBossDeath();
        return;
    }

    super.update(player, maze);

    if (!special && hp <= maxHp * 0.2) {
        special = true;
        specialAttack(player);
    }
}
 private void handleBossDeath() {
        if (deathHandled) return;   // run once
        deathHandled = true;

        // mark dead properly
        hp = 0;

        // 1) Tell quest system
        if (game.quest != null) {
            game.quest.completeBossQuest();
        }

        // 2) Add a prompt/log message (ensure GamePanel has addPrompt or similar)
        if (game != null) {
            // prefer a GamePanel method for logs instead of touching fields directly
            try {
                game.addPrompt("You defeated the boss!");
            } catch (Throwable t) {
                // fallback if addPrompt doesn't exist
                if (game.quest != null) game.quest.addMessage("You defeated the boss!");
            }
        }
 }



    private void specialAttack(Player player) {
        int dx = Math.abs(player.x - x);
        int dy = Math.abs(player.y - y);
        if (dx <= 160 && dy <= 160) {
            player.hp -= 30;
            if (game.quest != null) game.quest.addMessage("Boss used a devastating attack!");
        }
    }

    @Override
    public void draw(Graphics g) {
        if (hp <= 0) return;
        g.setColor(new Color(160,60,160));
        g.fillRect(x, y, width, height);
        g.setColor(Color.RED);
        int bw = (int)(width * ((double)hp / maxHp));
        g.fillRect(x, y - 10, bw, 6);
        g.setColor(Color.WHITE);
        g.drawRect(x, y - 10, width, 6);
    }
}