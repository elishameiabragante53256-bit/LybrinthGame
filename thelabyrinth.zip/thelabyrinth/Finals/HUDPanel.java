/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GameUli;

import javax.swing.*; 
import java.awt.*;

public class HUDPanel extends JPanel {

    private final GamePanel game;
    private final int height;

    public HUDPanel(GamePanel game, int height) {
        this.game = game;
        this.height = height;
        setOpaque(false);
        setPreferredSize(new Dimension(game.screenW, height));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int w = getWidth();
        g.setColor(new Color(30, 30, 30, 220));
        g.fillRect(0, 0, w, height);

        int leftX = 10;
        int midX = w / 3;
        int rightX = (w / 3) * 2;

        // ========== PLAYER STATS ==========
        if (game.player != null) {
            g.setColor(Color.white);
            g.drawString("HP: " + game.player.hp + " / " + game.player.maxHp, leftX, 18);

            g.setColor(Color.red);
            g.fillRect(leftX, 22, Math.max(1, (int)(100.0 * game.player.hp / game.player.maxHp)), 8);

            g.setColor(Color.white);
            g.drawString(
                    (game.player.resourceType == Player.ResourceType.MANA ? "Mana: " : "Stamina: ")
                            + game.player.resource + " / " + game.player.maxResource,
                    leftX, 46
            );

            g.setColor(game.player.resourceType == Player.ResourceType.MANA ? Color.blue : Color.yellow);
            g.fillRect(leftX, 50, Math.max(1, (int)(100.0 * game.player.resource / game.player.maxResource)), 8);

            g.setColor(Color.white);
            g.drawString("Level: " + game.player.level
                    + "   XP: " + game.player.xp + "/" + game.player.xpToNextLevel, leftX, 78);

            g.setColor(Color.green);
            g.fillRect(leftX, 82, Math.max(1, (int)(100.0 * game.player.xp / game.player.xpToNextLevel)), 8);

            g.setColor(Color.white);
            g.drawString("HP Potions: " + game.player.healthPotions
                    + "   Res Potions: " + game.player.resourcePotions, leftX, 102);
        }


        // ========== PROMPT LOG ==========
        g.setColor(Color.white);
        g.drawString("Prompt Log:", midX, 18);

        int logY = 34;
        for (String msg : game.quest.getMessages()) {
            g.drawString(msg, midX, logY);
            logY += 14;
        }


        // ========== QUEST INFO ==========
        g.setColor(Color.white);
        g.drawString("Quest:", leftX + 180, 18);

        int qY = 34;
        QuestSystem qs = game.quest;

        // --- Floor progression quest ---
        g.setColor(Color.white);
        g.drawString("• Current Floor: " + qs.getCurrentFloor() + " / 6", leftX + 180, qY);
        qY += 14;

        // --- Key Status ---
        switch (qs.state) {
            case FIND_KEY:
                g.setColor(Color.white);
                g.drawString("• Find the key", leftX + 180, qY);
                break;

            case KEY_SPAWNED:
                g.setColor(Color.yellow);
                g.drawString("• Key spawned!", leftX + 180, qY);
                break;

            case KEY_FOUND:
                g.setColor(Color.green);
                g.drawString("✔ Key found", leftX + 180, qY);
                break;

            case BOSS_UNLOCKED:
                g.setColor(Color.cyan);
                g.drawString("• Boss room unlocked!", leftX + 180, qY);
                break;

            case DEFEAT_BOSS:
                g.setColor(Color.orange);
                g.drawString("• Defeat the boss!", leftX + 180, qY);
                break;

            case COMPLETED:
                g.setColor(Color.green);
                g.drawString("✔ Quest Complete!", leftX + 180, qY);
                break;
        }

        qY += 18;


        // ========== CONTROLS ==========
        g.setColor(Color.white);
        g.drawString("Controls:", rightX, 18);
        g.drawString("SPACE: Attack", rightX, 36);
        g.drawString("I: Skill 1", rightX, 52);
        g.drawString("O: Skill 2", rightX, 68);
        g.drawString("Q: HP Potion", rightX, 84);
        g.drawString("E: Resource Potion", rightX, 100);
        g.drawString("F - Use / Descend stairs / Interactn", rightX, 116);
        g.drawString("ESC: Pause", rightX, 132);
    }
}
