/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GameUli;

import java.awt.*;

public class Projectile {
    public double x, y;
    public double dx, dy;
    public int width = 8, height = 8;
    public int damage;
    private boolean destroyed = false;
    private final GamePanel game;
    private final Player owner;
    private final double speed = 6.0; // projectile speed

    public Projectile(Player owner, GamePanel game, int damage) {
        this.owner = owner;
        this.game = game;
        this.damage = damage;

        this.x = owner.x + owner.width / 2 - width / 2;
        this.y = owner.y + owner.height / 2 - height / 2;

        // Auto-aim to nearest enemy
        Enemy target = findNearestEnemy();
        if (target != null) {
            double distX = (target.x + target.width/2) - x;
            double distY = (target.y + target.height/2) - y;
            double dist = Math.sqrt(distX*distX + distY*distY);
            dx = (distX / dist) * speed;
            dy = (distY / dist) * speed;
        } else {
            dx = owner.facingX * speed;
            dy = owner.facingY * speed;
        }
    }

    private Enemy findNearestEnemy() {
        Enemy nearest = null;
        double minDist = Double.MAX_VALUE;
        for (Enemy e : game.enemies) {
            if (e.hp <= 0) continue;
            double dist = Math.hypot(e.x - x, e.y - y);
            if (dist < minDist) {
                minDist = dist;
                nearest = e;
            }
        }
        return nearest;
    }

    public void update() {
        x += dx;
        y += dy;

        // Check wall collision
        if (game.maze.isWallAtPixel((int)x + width/2, (int)y + height/2)) {
            destroyed = true;
            return;
        }

        // Check enemy collision
        for (Enemy e : game.enemies) {
            if (e.hp <= 0) continue;
            if (x + width > e.x && x < e.x + e.width && y + height > e.y && y < e.y + e.height) {
                e.hp -= damage;
                game.quest.addMessage("Projectile hit for " + damage);
                destroyed = true;
                break;
            }
        }

        // Remove if out of screen
        if (x < 0 || x > game.screenW || y < 0 || y > game.screenH) destroyed = true;
    }

    public void draw(Graphics g) {
        g.setColor(Color.ORANGE);
        g.fillOval((int)x, (int)y, width, height);
    }

    public boolean isDestroyed() { return destroyed; }
}
