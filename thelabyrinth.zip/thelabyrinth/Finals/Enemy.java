/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GameUli;

import java.awt.*;
import java.util.Random;

public class Enemy {
    protected final GamePanel game;
    public int x, y;
    public int width = MazeGenerator.TILE_SIZE - 6;
    public int height = MazeGenerator.TILE_SIZE - 6;
    public int hp = 0;
    public int damage = 0;
    public double moveSpeed = 1.5;

    private int patrolDirX = 1, patrolDirY = 1;
    private int detectRange = 150;
    private int attackCooldown = 1;
    private Random rand = new Random();

    public Enemy(int px, int py, GamePanel game) {
        this.x = px;
        this.y = py;
        this.game = game;
    }

    public void update(Player player, MazeGenerator maze) {
        if (hp <= 0) return;

        if (attackCooldown > 0) attackCooldown--;

        int dx = player.x - x;
        int dy = player.y - y;
        double dist = Math.sqrt(dx*dx + dy*dy);

        if (dist < detectRange) moveTowardPlayer(dx, dy, maze);
        else patrol(maze);

        // Attack when close
        if (Math.abs(player.x - x) < width && Math.abs(player.y - y) < height && attackCooldown == 0) {
            player.hp -= 8;
            if (game.quest != null) game.quest.addMessage("You were hit!");
            attackCooldown = 30; // 1-second cooldown at 60 FPS
        }
    }

    private void moveTowardPlayer(int dx, int dy, MazeGenerator maze) {
        // Determine next positions
        int stepX = (int)Math.signum(dx);
        int stepY = (int)Math.signum(dy);

        int nx = x + (int)(stepX * moveSpeed);
        if (!maze.isWallAtPixel(nx + width/2, y + height/2)) x = nx;

        int ny = y + (int)(stepY * moveSpeed);
        if (!maze.isWallAtPixel(x + width/2, ny + height/2)) y = ny;
    }

    private void patrol(MazeGenerator maze) {
        // Patrol X
        int nx = x + (int)(patrolDirX * moveSpeed);
        if (!maze.isWallAtPixel(nx + width/2, y + height/2)) x = nx;
        else patrolDirX *= -1;

        // Patrol Y (randomized)
        if (rand.nextDouble() < 0.02) patrolDirY *= -1;
        int ny = y + (int)(patrolDirY * moveSpeed);
        if (!maze.isWallAtPixel(x + width/2, ny + height/2)) y = ny;
    }
    

    public void draw(Graphics g) {
        if (hp <= 0) return;
        g.setColor(Color.RED);
        g.fillRect(x, y, width, height);

        // Health bar
        g.setColor(Color.PINK);
        int bw = Math.min(60, Math.max(0, hp));
        g.fillRect(x, y - 6, bw, 4);
        g.setColor(Color.WHITE);
        g.drawRect(x, y - 6, 60, 4);
    }

    public boolean isDead(){ return hp <= 0; }
}
