/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GameUli;

import java.awt.*;

public abstract class Player {
    public enum ResourceType { STAMINA, MANA }
    public enum ClassType { WARRIOR, ROGUE, MAGE }

    public int x, y, width = MazeGenerator.TILE_SIZE - 4, height = MazeGenerator.TILE_SIZE - 4;
    public int hp, maxHp;
    public int resource, maxResource;
    public ResourceType resourceType;
    public int xp = 0, xpToNextLevel = 100, level = 1;
    public final ClassType preset;
    protected final GamePanel game;
    public boolean hasKey = false;


    public int healthPotions = 3;
    public int resourcePotions = 3;
    protected int potionCooldown = 0;

    protected int attackCooldown = 0;
    protected int skillCooldown = 0;
    protected int facingX = 1, facingY = 0; // direction player is facing

    public Player(ClassType preset, int sx, int sy, GamePanel game) {
        this.preset = preset;
        this.x = sx; this.y = sy;
        this.game = game;
    }

    // Update method for movement, attacks, and skills
    public abstract void update(boolean up, boolean down, boolean left, boolean right,
                                boolean attackKey, boolean key1, boolean key2, boolean qKey, boolean eKey, boolean rKey, MazeGenerator maze);

    // Method to move the player with wall and panel boundary checks
    protected void move(int dx, int dy, MazeGenerator maze) {
        int newX = x + dx;
        int newY = y + dy;

        // Check horizontal movement collision
        if (!maze.isWallAtPixel(newX + width/2, y + height/2)) {
            x = newX;
        }

        // Check vertical movement collision
        if (!maze.isWallAtPixel(x + width/2, newY + height/2)) {
            y = newY;
        }

        // Clamp within screen and HUD boundaries
        if (x < 0) x = 0;
        if (x > game.screenW - width) x = game.screenW - width;
        if (y < 0) y = 0;
        if (y > game.screenH - game.HUD_HEIGHT - height) y = game.screenH - game.HUD_HEIGHT - height;
    }

    // Gain XP and handle leveling
    public void gainXP(int amount) {
        xp += amount;
        if (game.quest != null) game.quest.addMessage("Gained " + amount + " XP");
        while (xp >= xpToNextLevel) levelUp();
    }

    protected void levelUp() {
        level++;
        xp -= xpToNextLevel;
        xpToNextLevel += 50;
        maxHp += 15;
        hp = maxHp;
        maxResource += 20;
        resource = maxResource;
        if (game.quest != null) game.quest.addMessage("Level up! Now level " + level);
    }

    // Health potion usage
    protected void useHealthPotion() {
        if (potionCooldown == 0 && healthPotions > 0 && hp < maxHp) {
            healthPotions--;
            hp += maxHp/2;
            if (hp > maxHp) hp = maxHp;
            potionCooldown = 120; // frames cooldown
            if (game.quest != null) game.quest.addMessage("Used Health Potion");
        }
    }

    // Resource (stamina/mana) potion usage
    protected void useResourcePotion() {
        if (potionCooldown == 0 && resourcePotions > 0 && resource < maxResource) {
            resourcePotions--;
            resource += maxResource/2;
            if (resource > maxResource) resource = maxResource;
            potionCooldown = 120;
            if (game.quest != null) game.quest.addMessage("Used Resource Potion");
        }
    }

    // Attack helper
    protected boolean canAttack() {
        return attackCooldown == 0 && resource >= getAttackCost();
    }

    // Skill helper
    protected boolean canUseSkill() {
        return skillCooldown == 0 && resource >= getSkillCost();
    }

    // Reduce resource for attack
    protected void useAttackResource() {
        resource -= getAttackCost();
        if (resource < 0) resource = 0;
        attackCooldown = 20; // example cooldown
    }

    // Reduce resource for skill
    protected void useSkillResource() {
        resource -= getSkillCost();
        if (resource < 0) resource = 0;
        skillCooldown = 30; // example cooldown
    }

    // Override in subclasses
    protected abstract int getAttackCost();
    protected abstract int getSkillCost();

    public abstract void draw(Graphics g);
}
