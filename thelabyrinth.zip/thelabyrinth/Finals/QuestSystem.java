/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GameUli;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

public class QuestSystem {
    public enum State { FIND_KEY, KEY_SPAWNED, KEY_FOUND, BOSS_UNLOCKED, DEFEAT_BOSS, COMPLETED }
    
    State state = State.FIND_KEY;
    
    private boolean keyFound = false;
    private boolean bossDefeated = false;
    
    private List<String> messages = new ArrayList<>();
    private int keyX = -1, keyY = -1;
    
        // <<<< Class-level variables for floor tracking
    private int currentFloor = 1;
    private final int totalFloors = 7;

    public QuestSystem() {
        addMessage("Quest: Complete each floor \nto reach the boss room.");
        addMessage("Current Floor: 1");
    }

    public void addMessage(String s) {
        messages.add(0, s);
        if (messages.size() > 6) messages.remove(messages.size()-1);
    }

    public java.util.List<String> getMessages() { return new ArrayList<>(messages); }

   public void update(Player player) {
        // Floor progression
        if (currentFloor < totalFloors && player.level >= currentFloor + 1) {
            currentFloor++;
            addMessage("Floor " + currentFloor + " unlocked! Explore to find the key.");
        }

        // Check if player picked up key
        checkKeyPickup(player);

        // Boss unlocked
        if (currentFloor == totalFloors && keyFound && state != State.BOSS_UNLOCKED) {
            state = State.BOSS_UNLOCKED;
            addMessage("Boss room unlocked! Proceed to defeat the boss.");
        }
        
        // Move to completed state
        if (bossDefeated && state != State.COMPLETED) {
            state = State.COMPLETED;
        }
    }
        public void completeBossQuest() {
        if (!bossDefeated) {
            bossDefeated = true;
            state = State.COMPLETED;
            addMessage("Quest Completed: Defeat the Boss!");
        }
    }
   
     private void spawnKeyForFloor() {
        // Random key placement, ensure not negative
        keyX = 100 + (int)(Math.random() * 400);
        keyY = 100 + (int)(Math.random() * 300);
        state = State.KEY_SPAWNED;
        keyFound = false;
        addMessage("A key has appeared for floor " + currentFloor + "!");
    }

    public void spawnKeyAt(int px, int py) {
        keyX = px; 
        keyY = py;
        state = State.KEY_SPAWNED;
        keyFound = false;
    }

    public int getKeyX() { return keyX; }
    public int getKeyY() { return keyY; }

     public void checkKeyPickup(Player player) {
    if (keyX < 0 || keyFound) return;

    // Check distance
    if (Math.hypot(player.x - keyX, player.y - keyY) < 24) {

        keyFound = true;
        state = State.KEY_FOUND;

        // *** CRITICAL FIX ***
        player.hasKey = true;

        addMessage("You picked up the key for floor " + currentFloor + "!");

        // Hide key from world
        keyX = -100;
        keyY = -100;
    }
}


    public void drawKey(Graphics g, MazeGenerator maze) {
        if (keyX >= 0 && !keyFound) {
            g.setColor(Color.ORANGE);
            g.fillOval(keyX - 8, keyY - 8, 16, 16);
        }
    }
    


    public boolean isKeyFound() { return keyFound; }
    public boolean isBossDefeated() { return bossDefeated; }
    public boolean isCompleted() { return state == State.COMPLETED; }

     public void setBossDefeated() {
        state = State.COMPLETED;
        addMessage("Boss defeated! Quest Completed!");
    }

    public int getCurrentFloor() { return currentFloor; }
}
