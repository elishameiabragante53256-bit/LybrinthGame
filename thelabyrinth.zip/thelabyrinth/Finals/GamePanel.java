/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GameUli;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class GamePanel extends JPanel implements KeyListener {
    public final int screenW = 960, screenH = 640;
    public final int HUD_HEIGHT = 120;
    
    private boolean paused = false;
    private boolean keySpawned = false;
    private boolean keyGiven = false;  

    
    private JButton continueBtn, exitBtn;


    private final GameWindow window;
    public MazeGenerator maze;
    public QuestSystem quest;
    public Player player;
    private FloorManager floorManager;
    
    
    public List<Enemy> enemies = new ArrayList<>();
    public List<Projectile> projectiles = new ArrayList<>();
    private java.util.List<String> promptMessages = new java.util.ArrayList<>();

    private HUDPanel hud;

    // input flags
    private boolean up, down, left, right, atk;
    private boolean key1, key2, keyQ, keyE, keyR, keyF;

    private Timer loop;
    public int currentFloor = 1;
    public final int maxFloors = 6;
    private Random rand = new Random();

    public GamePanel(Player.ClassType cls, GameWindow window) {
        this.window = window;
        this.quest = new QuestSystem();
        
        setPreferredSize(new Dimension(screenW, screenH));
        setLayout(null);
        setBackground(Color.black);
        setFocusable(true);
        addKeyListener(this);

        maze = new MazeGenerator(1  );

        int sx = maze.getSpawnX(), sy = maze.getSpawnY();
        
        int worldW = maze.cols * MazeGenerator.TILE_SIZE;
        int worldH = maze.rows * MazeGenerator.TILE_SIZE + HUD_HEIGHT;
        
        setPreferredSize(new Dimension(worldW, worldH));
        
        revalidate();


        floorManager = new FloorManager(this);

        if (cls == Player.ClassType.WARRIOR) player = new WARRIOR(sx, sy, this);
        else if (cls == Player.ClassType.ROGUE) player = new ROGUE(sx, sy, this);
        else player = new MAGE(sx, sy, this);

        quest = new QuestSystem();
        
        spawnEnemiesForFloor(currentFloor);
        
        hud = new HUDPanel(this, HUD_HEIGHT);
        hud.setBounds(0, screenH - HUD_HEIGHT, screenW, HUD_HEIGHT);
        add(hud);
        
        // Continue button
        continueBtn = new JButton("Continue");
        continueBtn.setBounds(screenW/2 - 60, screenH/2 - 40, 120, 30);
        continueBtn.addActionListener(e -> unpause());
        continueBtn.setVisible(false);
        add(continueBtn);

        // Exit button
        exitBtn = new JButton("Exit");
        exitBtn.setBounds(screenW/2 - 60, screenH/2 + 10, 120, 30);
        exitBtn.addActionListener(e -> window.showMenu());
        exitBtn.setVisible(false);
        add(exitBtn);
        
        setComponentZOrder(continueBtn, 0);
        setComponentZOrder(exitBtn, 0);
        continueBtn.setFocusable(false);
        exitBtn.setFocusable(false);

    }
    
    

    private void spawnEnemiesForFloor(int floor) {

    enemies.clear();
    FloorManager.FloorDefinition fd = FloorManager.get(floor);

    if (fd.isBossFloor) {
        int bx = maze.spawnX * MazeGenerator.TILE_SIZE;
        int by = maze.spawnY * MazeGenerator.TILE_SIZE;
        enemies.add(new Boss(bx, by, this));

        return;
    }

    int enemyCount = 5 + floor * 2;

    for (int i = 0; i < enemyCount; i++) {
        int tx = 2 + rand.nextInt(maze.cols - 4);
        int ty = 2 + rand.nextInt(maze.rows - 4);

        if (maze.isWallAtTile(tx, ty)) continue;

        int ex = maze.tileToPixelX(tx);
        int ey = maze.tileToPixelY(ty);

        try {
            Enemy e = fd.enemyType
                    .getDeclaredConstructor(int.class, int.class, GamePanel.class)
                    .newInstance(ex, ey, this);

            e.hp += floor * 50;
            e.moveSpeed += floor * 0.5;

            enemies.add(e);
        } catch (Exception excep) {
            excep.printStackTrace();
        }
    }
}

    
    private void unpause() {
    paused = false;
    continueBtn.setVisible(false);
    exitBtn.setVisible(false);
}


private void spawnKeyIfNeeded() {
    // Already handled key spawn?
    if (keySpawned || keyGiven) return;

    // Only spawn when ALL enemies are defeated
    if (!enemies.isEmpty()) return;

    keySpawned = true;
    
    // place key on valid tile
    for (int attempt = 0; attempt < 300; attempt++) {
        int cx = rand.nextInt(maze.cols);
        int cy = rand.nextInt(maze.rows);

        if (!maze.isWallAtTile(cx, cy)) {
            int kx = maze.tileToPixelX(cx);
            int ky = maze.tileToPixelY(cy);

            quest.spawnKeyAt(kx, ky);
            addPrompt("A mysterious key has appeared...");
            break;
        }
    }
}



    

public void addPrompt(String text) {
    promptMessages.add(0, text);
    if (promptMessages.size() > 6) promptMessages.remove(promptMessages.size() - 1);
}

// getter used by HUD
public java.util.List<String> getPromptMessages() {
    return new java.util.ArrayList<>(promptMessages);
}


    public void startGame() {
        requestFocusInWindow();
        loop = new Timer(16, e -> gameLoop());
        loop.start();
    }

  private void gameLoop() {
    if (!paused) updateGame();
    repaint();
}


    
    private void updateGame() {
        // pass input flags to player update (key1/key2 for skills, keyQ/E for potions, keyR for rogue throw)
        player.update(up, down, left, right, atk, key1, key2, keyQ, keyE, keyR, maze);

        // update enemies
        Iterator<Enemy> it = enemies.iterator();
        while (it.hasNext()) {
            Enemy en = it.next();
            en.update(player, maze);
            if (en.hp <= 0) {
                player.gainXP(en instanceof Boss ? 150 : 30);
                quest.addMessage("Enemy defeated! XP gained.");
                if (en instanceof Boss) {
                    quest.setBossDefeated();
                }
                it.remove();
            }
        }
        
        if (enemies.isEmpty()) {
    if (FloorManager.get(currentFloor).isBossFloor) {
        quest.setBossDefeated();
        addPrompt("Boss defeated!");
    }
}

        // update projectiles
        Iterator<Projectile> pit = projectiles.iterator();
        while (pit.hasNext()) {
            Projectile p = pit.next();
            p.update();
            if (p.isDestroyed()) pit.remove();
        }

        // reveal fog around player
        maze.revealAround(player.x + player.width/2, player.y + player.height/2, 6);

        // spawn key if reached level
        spawnKeyIfNeeded();

        // stairs interaction (F)
if (keyF) {
    if (maze.isStairsAt(player.x + player.width/2, player.y + player.height/2)) {

        if (!player.hasKey) {
            addPrompt("You need a key to use the stairs!");
            keyF = false;
            return; // BLOCK progress
        }
       

        player.hasKey = false;   // consume key
        keySpawned = false;      // reset spawn flag
        keyGiven = false;  

        if (currentFloor < maxFloors) {
            currentFloor++;

            maze = new MazeGenerator(currentFloor);
            player.x = maze.spawnX * MazeGenerator.TILE_SIZE;
            player.y = maze.spawnY * MazeGenerator.TILE_SIZE;

            spawnEnemiesForFloor(currentFloor);
            addPrompt("You ascended to Floor " + currentFloor);
        } else {
            addPrompt("This is the final floor!");
        }
    }
    keyF = false;
}

        // check key pickup
        quest.checkKeyPickup(player);

        quest.update(player);

        hud.repaint();
        


        if (player.hp <= 0) {
            loop.stop();
            JOptionPane.showMessageDialog(this, "YOU DIED", "Game Over", JOptionPane.INFORMATION_MESSAGE);
            window.showMenu();
        }

        if (quest.isCompleted()) {
            loop.stop();
            JOptionPane.showMessageDialog(this, "YOU WIN! Quest Completed", "Victory", JOptionPane.INFORMATION_MESSAGE);
            window.showMenu();
        }
        
    }
    private void togglePause() {
    paused = !paused;
    continueBtn.setVisible(paused);
    exitBtn.setVisible(paused);
}


    @Override protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        maze.draw(g, 0, 0, screenW, screenH - HUD_HEIGHT);
        quest.drawKey(g, maze);
       



        for (Enemy en : enemies) en.draw(g);
        for (Projectile p : projectiles) p.draw(g);
        player.draw(g);
        
        if (paused) {
            g.setColor(new Color(0, 0, 0, 150));
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 24));
            g.drawString("PAUSED", 16, 34);        }
    }

    @Override public void keyTyped(KeyEvent e) {}
    @Override public void keyPressed(KeyEvent e) { setKey(e, true); }
    @Override public void keyReleased(KeyEvent e) { setKey(e, false); }
    
    

    private void setKey(KeyEvent e, boolean pressed) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_W -> up = pressed;
            case KeyEvent.VK_S -> down = pressed;
            case KeyEvent.VK_A -> left = pressed;
            case KeyEvent.VK_D -> right = pressed;
            case KeyEvent.VK_SPACE -> atk = pressed;
            case KeyEvent.VK_I -> key1 = pressed;
            case KeyEvent.VK_O -> key2 = pressed;
            case KeyEvent.VK_Q -> keyQ = pressed;
            case KeyEvent.VK_E -> keyE = pressed;
            case KeyEvent.VK_R -> keyR = pressed;
            case KeyEvent.VK_F -> keyF = pressed;
            case KeyEvent.VK_ESCAPE -> {
    if (pressed) togglePause();
}


        }
    }

}
