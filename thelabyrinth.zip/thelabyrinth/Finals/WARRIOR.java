/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GameUli;

import java.awt.*;

public class WARRIOR extends Player {
    private final int baseDamage = 30;
    private int rageTimer = 0;

    public WARRIOR(int spawnX, int spawnY, GamePanel game) {
        super(ClassType.WARRIOR, spawnX, spawnY, game);
        this.maxHp = 220; this.hp = maxHp;
        this.maxResource = 120; this.resource = maxResource;
        this.resourceType = ResourceType.STAMINA;
    }

    @Override
    public void update(boolean up, boolean down, boolean left, boolean right,
                       boolean attackKey, boolean key1, boolean key2, boolean qKey, boolean eKey, boolean rKey, MazeGenerator maze) {
        int speed = 4;
        int newX = x, newY = y;
        if (up) newY -= speed;
        if (down) newY += speed;
        if (left) newX -= speed;
        if (right) newX += speed;

        if (newX != x) facingX = Integer.signum(newX - x);
        if (newY != y) facingY = Integer.signum(newY - y);

        if (!maze.isWallAtPixel(newX + width/2, y + height/2)) x = newX;
        if (!maze.isWallAtPixel(x + width/2, newY + height/2)) y = newY;

        if (resource < maxResource) resource++;

        if (attackKey && attackCooldown == 0) {
            melee();
            attackCooldown = 18;
        }
        if (attackCooldown > 0) attackCooldown--;

        if (key1) {
            if (resource >= 15 && skillCooldown == 0) {
                resource -= 15;
                for (Enemy e : game.enemies) {
                    int dx = Math.abs((e.x + e.width/2) - (x + width/2));
                    int dy = Math.abs((e.y + e.height/2) - (y + height/2));
                    if (dx <= 70 && dy <= 50) {
                        e.hp -= baseDamage + level*2;
                        e.x += (e.x > x) ? 30 : -30;
                    }
                }
                game.quest.addMessage("Warrior used Shield Bash!");
                skillCooldown = 60;
            } else if (skillCooldown == 0) game.quest.addMessage("Not enough Stamina!");
        }

        if (key2) {
            if (resource >= 40 && skillCooldown == 0) {
                resource -= 40;
                rageTimer = 300;
                game.quest.addMessage("Warrior activated Berserk!");
                skillCooldown = 300;
            } else if (skillCooldown == 0) game.quest.addMessage("Not enough Stamina for Berserk!");
        }

        if (rageTimer > 0) rageTimer--;
        if (skillCooldown > 0) skillCooldown--;
        if (potionCooldown > 0) potionCooldown--;
        if (qKey) useHealthPotion();
        if (eKey) useResourcePotion();
    }

    private void melee() {
        for (Enemy e : game.enemies) {
            int dx = Math.abs((e.x + e.width/2) - (x + width/2));
            int dy = Math.abs((e.y + e.height/2) - (y + height/2));
            if (dx <= 48 && dy <= 48) {
                int dmg = baseDamage + level*2 + (rageTimer>0?8:0);
                e.hp -= dmg;
                game.quest.addMessage("Warrior hits for " + dmg);
            }
        }
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(new Color(180,60,60));
        g.fillRect(x, y, width, height);
    }

    @Override
    protected int getAttackCost() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    protected int getSkillCost() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
