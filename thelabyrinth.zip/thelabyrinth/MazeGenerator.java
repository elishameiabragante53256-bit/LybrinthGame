package thelabyrinth;

import java.awt.*;
import java.util.Random;
import javax.swing.*;

public class MazeGenerator {

    public static final int TILE_SIZE = 32;

    public int cols, rows;
    public int[][] grid;
    public int stairsX, stairsY;
    public int spawnX, spawnY;

    private boolean[][] explored;
    private boolean[][] torchAt;
    private int[][] wallVariant;
    private Random rand = new Random();
    private int currentFloor;


    public MazeGenerator(int floor) {
        loadFloor(floor);
    }

    private void loadFloor(int floor) {
        currentFloor = floor;
        switch (floor) {
            case 1: loadCaveMap(); break;
            case 2: loadForestMap(); break;
            case 3: loadRuinsMap(); break;
            case 4: loadIceMap(); break;
            case 5: loadFireMap(); break;
            case 6: loadBossRoom(); break;
            default: loadCaveMap();
        }
    }

    private void initGrid(int c, int r) {
        cols = c; rows = r;
        grid = new int[rows][cols];
        explored = new boolean[rows][cols];
        torchAt = new boolean[rows][cols];
        wallVariant = new int[rows][cols];

        for (int y = 0; y < rows; y++) {
            for (int x = 0; x < cols; x++) {
                grid[y][x] = (y == 0 || x == 0 || y == rows - 1 || x == cols - 1) ? 1 : 0;
                wallVariant[y][x] = rand.nextInt(3);
            }
        }

        for (int y = 1; y < rows - 1; y++) {
            for (int x = 1; x < cols - 1; x++) {
                if (grid[y][x] == 1 && rand.nextDouble() < 0.04)
                    torchAt[y][x] = true;
            }
        }
    }

    // =========================================================
    // ----------------------- FLOOR 1 --------------------------
    //                      CAVE ROOM
    // =========================================================
    private void loadCaveMap() {
        initGrid(30, 17);
        for (int i = 0; i < 12; i++) {
            int cx = 3 + rand.nextInt(cols - 6);
            int cy = 3 + rand.nextInt(rows - 6);
            int w = 1 + rand.nextInt(3);
            int h = 1 + rand.nextInt(3);
            for (int ry = 0; ry < h; ry++)
                for (int rx = 0; rx < w; rx++)
                    grid[Math.min(rows - 2, cy + ry)][Math.min(cols - 2, cx + rx)] = 1;
        }
        for (int px = 5; px < cols - 5; px += 8) {
            grid[rows / 2][px] = 0;
            grid[rows / 2 + 1][px] = 0;
        }
        spawnX = cols / 2;
        spawnY = rows / 2;
        stairsX = cols - 3;
        stairsY = rows - 3;
        carveSafeSpawn();
    }

    // =========================================================
    // ----------------------- FLOOR 2 --------------------------
    //                      FOREST ROOM
    // =========================================================
    private void loadForestMap() {
        initGrid(30, 17);

        // Place trees as walls
        for (int c = 4; c < cols - 4; c += 3) {
            int base = 4 + rand.nextInt(rows - 8);
            for (int t = 0; t < 3; t++) {
                int rr = base + rand.nextInt(5) - 2;
                if (rr > 1 && rr < rows - 1) grid[rr][c] = 1;
            }
        }

        // Random trees / bushes
        for (int i = 0; i < 20; i++) {
            int r = 3 + rand.nextInt(rows - 6);
            int c = 3 + rand.nextInt(cols - 6);
            if (rand.nextDouble() < 0.6) grid[r][c] = 1;
        }

        spawnX = 2;
        spawnY = 2;
        stairsX = cols - 4;
        stairsY = rows - 2;

        carveSafeSpawn();
    }

    // =========================================================
    // ----------------------- FLOOR 3 --------------------------
    //                      RUINS ROOM
    // =========================================================
    private void loadRuinsMap() {
       initGrid(30, 17);

        // vertical ruined walls
        for (int r = 3; r < rows-3; r++) {
            if (r%2==0) grid[r][8] = 1;
            if (r%3==0) grid[r][15] = 1;
            if (r%4==0) grid[r][22] = 1;
        }

        // scattered rubble
        for (int i=0;i<18;i++) {
            int r = 3 + rand.nextInt(rows-6);
            int c = 3 + rand.nextInt(cols-6);
            grid[r][c] = 1;
        }

        spawnX = 3;
        spawnY = 3;
        stairsX = cols - 4;
        stairsY = rows - 3;
        
        carveSafeSpawn();
    }
    
    // =========================================================
    // ----------------------- FLOOR 4 --------------------------
    //                      ICE ROOM
    // =========================================================
    private void loadIceMap() {
        initGrid(30, 17);

        // Random icy walls
        for (int i = 0; i < 15; i++) {
            int r = 2 + rand.nextInt(rows - 4);
            int c = 2 + rand.nextInt(cols - 4);
            grid[r][c] = 1;
            if (rand.nextBoolean() && r < rows - 2) grid[r + 1][c] = 1;
            if (rand.nextBoolean() && c < cols - 2) grid[r][c + 1] = 1;
        }

        // Frozen path from spawn to stairs
        for (int c = 2; c < cols - 2; c++) grid[rows / 2][c] = 0;
        for (int r = 2; r < rows - 2; r++) grid[r][cols / 2] = 0;

        spawnX = 2;
        spawnY = rows / 2;
        stairsX = cols - 3;
        stairsY = rows / 2;

        carveSafeSpawn();
    }

    // =========================================================
    // ----------------------- FLOOR 5 --------------------------
    //                       FIRE ROOM
    // =========================================================
    private void loadFireMap() {
         initGrid(30, 17);

        // fire pillar lines
        for (int r = 4; r < rows-4; r+=2) grid[r][cols/2] = 1;

        // add side channels of obstacles
        for (int i=0;i<12;i++) {
            int r = 4 + rand.nextInt(rows-8);
            int c = 3 + rand.nextInt(6);
            grid[r][c] = 1;
            grid[r][cols-1-c] = 1;
        }

        spawnX = 2;
        spawnY = rows - 4;
        stairsX = cols - 4;
        stairsY = 3;
        
        carveSafeSpawn();
    }
    
    private void loadBossRoom() { 
        initGrid(30,17); 
        
                // carve a large central arena 9x7 tiles
        int arenaW = 13, arenaH = 9;
        int ax = (cols - arenaW)/2, ay = (rows - arenaH)/2;
        for (int r = ay; r < ay + arenaH; r++)
            for (int c = ax; c < ax + arenaW; c++)
                grid[r][c] = 0;

        // place a few decorative pillars in arena edges
        grid[ay+1][ax+2] = 1; grid[ay+2][ax+2] = 1;
        grid[ay+1][ax+arenaW-3] = 1; grid[ay+2][ax+arenaW-3] = 1;

        spawnX = cols / 2;
        spawnY = rows / 2;
        stairsX = cols - 3;
        stairsY = rows - 3;
        
        carveSafeSpawn();
    }

    public void carveSafeSpawn() {
        for (int y = spawnY - 2; y <= spawnY + 2; y++) {
            for (int x = spawnX - 2; x <= spawnX + 2; x++) {
                if (x > 0 && x < cols - 1 && y > 0 && y < rows - 1)
                    grid[y][x] = 0;
            }
        }
    }

    // TILE CHECKS
    public boolean isWallAtPixel(int px, int py) {
        int c = px / TILE_SIZE;
        int r = py / TILE_SIZE;
        if (r < 0 || r >= rows || c < 0 || c >= cols) return true;
        return grid[r][c] == 1;
    }

    public boolean isStairsAt(int px, int py) {
        int tX = px / TILE_SIZE;
        int tY = py / TILE_SIZE;
        return tX == stairsX && tY == stairsY;
    }

    public void revealAround(int px, int py, int radius) {
        int tx = px / TILE_SIZE;
        int ty = py / TILE_SIZE;
        for (int r = -radius; r <= radius; r++)
            for (int c = -radius; c <= radius; c++) {
                int rr = ty + r, cc = tx + c;
                if (rr >= 0 && rr < rows && cc >= 0 && cc < cols)
                    explored[rr][cc] = true;
            }
    }

    public int getSpawnX() { return spawnX * TILE_SIZE; }
    public int getSpawnY() { return spawnY * TILE_SIZE; }
    public boolean isWallAtTile(int tx, int ty) { if (tx < 0 || tx >= cols || ty < 0 || ty >= rows) return true; return grid[ty][tx] == 1; }
    public int tileToPixelX(int tx) { return tx * TILE_SIZE; }
    public int tileToPixelY(int ty) { return ty * TILE_SIZE; }

    // ============================================================
    //                           DRAW
    // ============================================================
    public void draw(Graphics g, int xOff, int yOff, int screenW, int screenH) {
        Graphics2D g2 = (Graphics2D) g;

        // --- TILES ---
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int px = c * TILE_SIZE + xOff;
                int py = r * TILE_SIZE + yOff;

                if (grid[r][c] == 1) {
                    // WALL TILES
                    if (currentFloor == 1) {
                        drawCaveWall(g2, px, py, r, c);
                    } else if (currentFloor == 2) {
                        drawTree(g2, px, py);
                    } else if (currentFloor == 3) {
                        drawRuinsWall(g2, px, py, r, c);
                    } else if (currentFloor == 4) {
                        drawIceWall(g2, px, py);  // ICE WALL
                    } else if (currentFloor == 5) {
                        drawFireWall(g2, px, py);  // FIRE WALL
                    } else if (currentFloor == 6) {
                        drawBossWall(g2, px, py);  // BOSS WALL
                    } else {
                        g2.setColor(Color.DARK_GRAY);
                        g2.fillRect(px, py, TILE_SIZE, TILE_SIZE);
                    }
                } else {
                    // FLOOR TILES
                    if (currentFloor == 1) {
                        drawCaveFloor(g2, px, py);
                    } else if (currentFloor == 2) {
                        drawForestFloor(g2, px, py);
                    } else if (currentFloor == 3) {
                        drawRuinsFloor(g2, px, py);
                    } else if (currentFloor == 4) {
                        drawIceFloor(g2, px, py);  // ICE FLOOR
                    } else if (currentFloor == 5) {
                        drawFireFloor(g2, px, py);  // FIRE FLOOR
                    } else if (currentFloor == 6) {
                        drawBossFloor(g2, px, py);  // BOSS FLOOR
                    } else {
                        g2.setColor(Color.BLACK);
                        g2.fillRect(px, py, TILE_SIZE, TILE_SIZE);
                    }
                }

                if (torchAt[r][c]) drawTorch(g2, px, py);
            }
        }

        // --- STAIRS ---
        g2.setColor(Color.ORANGE);
        g2.fillRect(stairsX * TILE_SIZE + xOff, stairsY * TILE_SIZE + yOff, TILE_SIZE, TILE_SIZE);
    }
    
    // ==================== CAVE FLOOR/WALL ====================
    private void drawCaveFloor(Graphics2D g, int px, int py) {
        int R = 110 + rand.nextInt(15);
        int G = 95 + rand.nextInt(10);
        int B = 70 + rand.nextInt(10);
        g.setColor(new Color(R, G, B));
        g.fillRect(px, py, TILE_SIZE, TILE_SIZE);

        g.setColor(new Color(Math.max(0,R - 25), Math.max(0,G - 20), Math.max(0,B - 15)));
        for (int i = 0; i < 3; i++) g.fillOval(px + rand.nextInt(TILE_SIZE - 6), py + rand.nextInt(TILE_SIZE - 6), 6, 6);

        g.setColor(new Color(Math.min(255,R + 20), Math.min(255,G + 15), Math.min(255,B + 10)));
        if (rand.nextDouble() < 0.3) g.fillOval(px + rand.nextInt(20), py + rand.nextInt(20), 4, 4);
    }

    private void drawCaveWall(Graphics2D g, int px, int py, int r, int c) {
        int baseR = 90 + rand.nextInt(30);
        int baseG = 70 + rand.nextInt(20);
        int baseB = 50 + rand.nextInt(20);
        g.setColor(new Color(baseR, baseG, baseB, 220));
        g.fillRoundRect(px, py, TILE_SIZE, TILE_SIZE, 10, 10);

        g.setColor(new Color(40, 30, 20, 120));
        g.fillRect(px, py + TILE_SIZE - 6, TILE_SIZE, 6);
        g.fillRect(px + TILE_SIZE - 6, py, 6, TILE_SIZE);

        g.setColor(new Color(180, 160, 130, 90));
        g.drawLine(px + 2, py + 2, px + TILE_SIZE - 4, py + 2);
        g.drawLine(px + 2, py + 2, px + 2, py + TILE_SIZE - 4);

        if (rand.nextDouble() < 0.45) {
            g.setColor(new Color(60, 45, 30, 180));
            int yMid = py + TILE_SIZE / 2 + rand.nextInt(5) - 2;
            g.drawLine(px + 3, yMid, px + TILE_SIZE - 3, yMid);
        }

        if (rand.nextDouble() < 0.30) {
            int xSplit = px + rand.nextInt(TILE_SIZE - 10) + 5;
            g.drawLine(xSplit, py + 3, xSplit, py + TILE_SIZE - 3);
        }

        if (rand.nextDouble() < 0.20) {
            g.setColor(new Color(30, 25, 20, 140));
            g.fillOval(px + 5 + rand.nextInt(TILE_SIZE - 10), py + 5 + rand.nextInt(TILE_SIZE - 10), 6, 6);
        }

        if (rand.nextDouble() < 0.20) {
            g.setColor(new Color(20, 15, 10, 160));
            int x1 = px + rand.nextInt(TILE_SIZE - 6) + 3;
            int y1 = py + rand.nextInt(TILE_SIZE - 6) + 3;
            int x2 = x1 + rand.nextInt(10) - 5;
            int y2 = y1 + rand.nextInt(10) - 5;
            g.drawLine(x1, y1, x2, y2);
        }

        if (rand.nextDouble() < 0.05) {
            g.setColor(new Color(40, 90, 40, 120));
            g.fillOval(px + rand.nextInt(18), py + rand.nextInt(18), 7, 7);
        }
    }

    // ==================== FOREST FLOOR/WALL ====================
    private void drawForestFloor(Graphics2D g, int px, int py) {
        int R = 50 + rand.nextInt(20);
        int G = 120 + rand.nextInt(30);
        int B = 50 + rand.nextInt(20);
        g.setColor(new Color(R,G,B));
        g.fillRect(px, py, TILE_SIZE, TILE_SIZE);

        g.setColor(new Color(R-15, G-20, B-15));
        for (int i = 0; i < 2; i++) {
            int sx = px + rand.nextInt(TILE_SIZE-4);
            int sy = py + rand.nextInt(TILE_SIZE-4);
            g.fillOval(sx, sy, 4, 4);
        }

        if (rand.nextDouble() < 0.2) {
            g.setColor(new Color(200+rand.nextInt(55), 180+rand.nextInt(75), 200+rand.nextInt(55)));
            g.fillOval(px + rand.nextInt(TILE_SIZE-4), py + rand.nextInt(TILE_SIZE-4), 3, 3);
        }
    }

    private void drawTree(Graphics2D g, int px, int py) {
        g.setColor(new Color(90,60,40));
        g.fillRect(px + 10, py + 10, 12, 12);

        g.setColor(new Color(30 + rand.nextInt(30), 120 + rand.nextInt(50), 30 + rand.nextInt(30)));
        g.fillOval(px + 2, py, 28, 20);

        g.setColor(new Color(0,0,0,40));
        g.fillOval(px + 5, py + 5, 20, 5);
    }

    // ==================== RUINS FLOOR/WALL ====================
    private void drawRuinsFloor(Graphics2D g, int px, int py) {
        int R = 100 + rand.nextInt(20);
        int G = 100 + rand.nextInt(20);
        int B = 90 + rand.nextInt(20);
        g.setColor(new Color(R,G,B));
        g.fillRect(px, py, TILE_SIZE, TILE_SIZE);

        if (rand.nextDouble() < 0.4) {
            g.setColor(new Color(60,60,60,150));
            int x1 = px + 4 + rand.nextInt(20);
            int y1 = py + 4 + rand.nextInt(20);
            int x2 = x1 + rand.nextInt(10)-5;
            int y2 = y1 + rand.nextInt(10)-5;
            g.drawLine(x1, y1, x2, y2);
        }

        if (rand.nextDouble() < 0.35) {
            g.setColor(new Color(40,80,40,140));
            g.fillOval(px + rand.nextInt(20), py + rand.nextInt(20), 8, 8);
        }

        g.setColor(new Color(R+20, G+20, B+20, 90));
        g.fillRect(px, py, TILE_SIZE, 4);
    }

    private void drawRuinsWall(Graphics2D g, int px, int py, int r, int c) {
        int R = 90 + rand.nextInt(25);
        int G = 85 + rand.nextInt(25);
        int B = 80 + rand.nextInt(25);
        g.setColor(new Color(R,G,B));
        g.fillRect(px, py, TILE_SIZE, TILE_SIZE);

        g.setColor(new Color(40,40,40,120));
        g.fillRect(px, py + TILE_SIZE - 5, TILE_SIZE, 5);
        g.fillRect(px + TILE_SIZE - 5, py, 5, TILE_SIZE);

        g.setColor(new Color(150,150,150,90));
        g.drawRect(px + 2, py + 2, TILE_SIZE - 4, TILE_SIZE - 4);

        if (rand.nextDouble() < 0.5) {
            g.setColor(new Color(50,50,50,150));
            int x1 = px + 5 + rand.nextInt(20);
            int y1 = py + 5 + rand.nextInt(20);
            int x2 = x1 + rand.nextInt(12)-6;
            int y2 = y1 + rand.nextInt(12)-6;
            g.drawLine(x1, y1, x2, y2);
        }

        if (rand.nextDouble() < 0.35) {
            g.setColor(new Color(30,70,30,150));
            g.fillOval(px + rand.nextInt(18), py + rand.nextInt(18), 10, 10);
        }

        if (rand.nextDouble() < 0.1) {
            g.setColor(new Color(200,200,180,180));
            g.drawString("ᚠ", px + 10, py + 20);
        }
    }

    private void drawTorch(Graphics2D g2, int px, int py) {
        g2.setColor(Color.YELLOW);
        g2.fillOval(px + 10, py + 10, 12, 12);
    }
    
    // ==================== ICE FLOOR/WALL ====================
    private void drawIceFloor(Graphics2D g, int px, int py) {
        // Simple blue-white floor
        g.setColor(new Color(200, 230, 255));
        g.fillRect(px, py, TILE_SIZE, TILE_SIZE);
        
        // White snow spots
        if (rand.nextDouble() < 0.3) {
            g.setColor(Color.WHITE);
            int size = 3 + rand.nextInt(4);
            int x = px + rand.nextInt(TILE_SIZE - size);
            int y = py + rand.nextInt(TILE_SIZE - size);
            g.fillOval(x, y, size, size);
        }
    }

    private void drawIceWall(Graphics2D g, int px, int py) {
        // Blue ice wall
        g.setColor(new Color(170, 210, 240));
        g.fillRect(px, py, TILE_SIZE, TILE_SIZE);
        
        // White border
        g.setColor(new Color(220, 240, 255));
        g.drawRect(px, py, TILE_SIZE - 1, TILE_SIZE - 1);
        
        // White ice crystals
        g.setColor(Color.WHITE);
        for (int i = 0; i < 2; i++) {
            int x = px + 5 + rand.nextInt(TILE_SIZE - 10);
            int y = py + 5 + rand.nextInt(TILE_SIZE - 10);
            g.fillOval(x, y, 2, 2);
        }
    }

       // ==================== FIRE FLOOR/WALL ====================
    private void drawFireFloor(Graphics2D g, int px, int py) {
        // Lava base color
        int R = 200 + rand.nextInt(30);
        int G = 80 + rand.nextInt(20);
        int B = 40 + rand.nextInt(15);
        g.setColor(new Color(R, G, B));
        g.fillRect(px, py, TILE_SIZE, TILE_SIZE);

        // Darker lava cracks
        g.setColor(new Color(Math.max(0, R - 40), Math.max(0, G - 30), Math.max(0, B - 20), 150));
        for (int i = 0; i < 3; i++) {
            g.fillOval(px + rand.nextInt(TILE_SIZE - 8), py + rand.nextInt(TILE_SIZE - 8), 8, 8);
        }

        // Bright glowing lava spots
        g.setColor(new Color(Math.min(255, R + 30), Math.min(255, G + 40), Math.min(255, B + 30), 180));
        if (rand.nextDouble() < 0.4) {
            g.fillOval(px + rand.nextInt(TILE_SIZE - 6), py + rand.nextInt(TILE_SIZE - 6), 6, 6);
        }

        // Small hot embers
        g.setColor(new Color(255, 180, 80, 200));
        for (int i = 0; i < 2; i++) {
            g.fillOval(px + rand.nextInt(TILE_SIZE - 4), py + rand.nextInt(TILE_SIZE - 4), 4, 4);
        }
    }

    private void drawFireWall(Graphics2D g, int px, int py) {
        // Charred stone base
        int baseR = 100 + rand.nextInt(30);
        int baseG = 60 + rand.nextInt(20);
        int baseB = 40 + rand.nextInt(15);
        g.setColor(new Color(baseR, baseG, baseB, 220));
        g.fillRoundRect(px, py, TILE_SIZE, TILE_SIZE, 8, 8);

        // Dark shadow at bottom
        g.setColor(new Color(70, 40, 25, 120));
        g.fillRect(px, py + TILE_SIZE - 6, TILE_SIZE, 6);
        g.fillRect(px + TILE_SIZE - 6, py, 6, TILE_SIZE);

        // Glowing edges (like cave wall highlights)
        g.setColor(new Color(220, 120, 60, 90));
        g.drawLine(px + 2, py + 2, px + TILE_SIZE - 4, py + 2);
        g.drawLine(px + 2, py + 2, px + 2, py + TILE_SIZE - 4);

        // Lava cracks through walls
        if (rand.nextDouble() < 0.5) {
            g.setColor(new Color(240, 100, 50, 180));
            int yCrack = py + TILE_SIZE / 2 + rand.nextInt(5) - 2;
            g.drawLine(px + 3, yCrack, px + TILE_SIZE - 3, yCrack);
        }

        // Vertical lava flows
        if (rand.nextDouble() < 0.35) {
            int xCrack = px + rand.nextInt(TILE_SIZE - 10) + 5;
            g.setColor(new Color(230, 90, 45, 160));
            g.drawLine(xCrack, py + 3, xCrack, py + TILE_SIZE - 3);
        }

        // Glowing lava pockets
        if (rand.nextDouble() < 0.25) {
            g.setColor(new Color(255, 140, 60, 140));
            g.fillOval(px + 5 + rand.nextInt(TILE_SIZE - 10), py + 5 + rand.nextInt(TILE_SIZE - 10), 8, 8);
        }

        // Small crack lines
        if (rand.nextDouble() < 0.25) {
            g.setColor(new Color(180, 80, 40, 160));
            int x1 = px + rand.nextInt(TILE_SIZE - 6) + 3;
            int y1 = py + rand.nextInt(TILE_SIZE - 6) + 3;
            int x2 = x1 + rand.nextInt(10) - 5;
            int y2 = y1 + rand.nextInt(10) - 5;
            g.drawLine(x1, y1, x2, y2);
        }

        // Hot glowing embers on walls
        if (rand.nextDouble() < 0.1) {
            g.setColor(new Color(255, 200, 100, 120));
            g.fillOval(px + rand.nextInt(18), py + rand.nextInt(18), 7, 7);
        }
    }
    // ==================== BOSS ROOM FLOOR/WALL ====================
    private void drawBossFloor(Graphics2D g, int px, int py) {
        // Dark ominous floor for boss room
        g.setColor(new Color(30, 20, 40)); // Dark purple/black
        g.fillRect(px, py, TILE_SIZE, TILE_SIZE);
        
        // Blood red patterns
        if (rand.nextDouble() < 0.3) {
            g.setColor(new Color(150, 30, 30, 180));
            int patternX = px + rand.nextInt(TILE_SIZE - 6);
            int patternY = py + rand.nextInt(TILE_SIZE - 6);
            int patternSize = 3 + rand.nextInt(4);
            g.fillOval(patternX, patternY, patternSize, patternSize);
        }
        
        // Dark gray cracks
        if (rand.nextDouble() < 0.2) {
            g.setColor(new Color(60, 60, 60));
            int crackX1 = px + 2 + rand.nextInt(TILE_SIZE - 4);
            int crackY1 = py + 2 + rand.nextInt(TILE_SIZE - 4);
            int crackX2 = crackX1 + rand.nextInt(8) - 4;
            int crackY2 = crackY1 + rand.nextInt(8) - 4;
            g.drawLine(crackX1, crackY1, crackX2, crackY2);
        }
    }

    private void drawBossWall(Graphics2D g, int px, int py) {
        // Dark stone walls with ominous glow
        g.setColor(new Color(50, 40, 60)); // Dark purple stone
        g.fillRect(px, py, TILE_SIZE, TILE_SIZE);
        
        // Glowing red runes/cracks
        g.setColor(new Color(180, 40, 40, 150));
        for (int i = 0; i < 3; i++) {
            int glowX = px + 3 + rand.nextInt(TILE_SIZE - 6);
            int glowY = py + 3 + rand.nextInt(TILE_SIZE - 6);
            int glowSize = 2 + rand.nextInt(4);
            g.fillOval(glowX, glowY, glowSize, glowSize);
        }
        
        // Darker borders for depth
        g.setColor(new Color(30, 20, 40));
        g.drawRect(px, py, TILE_SIZE - 1, TILE_SIZE - 1);
        
        // Occasional skull/bone symbol
        if (rand.nextDouble() < 0.05) {
            g.setColor(new Color(200, 200, 200, 180));
            g.drawString("💀", px + 8, py + 20);
        }
    }
}