/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thelabyrinth;

import java.awt.*;

public class ROGUE extends Player {
    private final int baseDamage = 25;
    private int poisonStacks = 0;

    public ROGUE(int spawnX, int spawnY, GamePanel game) {
        super(ClassType.ROGUE, spawnX, spawnY, game);
        this.maxHp = 150; this.hp = maxHp;
        this.maxResource = 160; this.resource = maxResource;
        this.resourceType = ResourceType.STAMINA;
    }

    @Override
    public void update(boolean up, boolean down, boolean left, boolean right,
                       boolean attackKey, boolean key1, boolean key2, boolean qKey, boolean eKey, boolean rKey, MazeGenerator maze) {
        int speed = 6;
        int newX = x, newY = y;
        if (up) newY -= speed;
        if (down) newY += speed;
        if (left) newX -= speed;
        if (right) newX += speed;

        if (newX != x) facingX = Integer.signum(newX - x);
        if (newY != y) facingY = Integer.signum(newY - y);

        if (!maze.isWallAtPixel(newX + width/2, y + height/2)) x = newX;
        if (!maze.isWallAtPixel(x + width/2, newY + height/2)) y = newY;

        if (resource < maxResource) resource++;

        if (key1 && skillCooldown == 0) {
            if (resource >= 20) {
                resource -= 20;
                stab();
                skillCooldown = 30;
            } else game.quest.addMessage("Not enough Stamina for Stab!");
        }

        if (key2 && skillCooldown == 0) {
            if (resource >= 25) {
                resource -= 25;
                poisonStacks = 3;
                game.quest.addMessage("Rogue applied poison to blade!");
                skillCooldown = 120;
            } else game.quest.addMessage("Not enough Stamina for Poison!");
        }

        if (rKey && rKey) {
            // throwing handled by GamePanel if desired (projectile spawn on key press)
        }

        if (attackKey && attackCooldown == 0) {
            if (resource >= 6) {
                resource -= 6;
                melee();
            } else game.quest.addMessage("Not enough Stamina to attack!");
            attackCooldown = 14;
        }
        if (attackCooldown > 0) attackCooldown--;

        if (skillCooldown > 0) skillCooldown--;
        if (potionCooldown > 0) potionCooldown--;
        if (qKey) useHealthPotion();
        if (eKey) useResourcePotion();
    }

    private void stab() {
        for (Enemy e : game.enemies) {
            int dx = Math.abs((e.x + e.width/2) - (x + width/2));
            int dy = Math.abs((e.y + e.height/2) - (y + height/2));
            if (dx <= 60 && dy <= 60) {
                int dmg = baseDamage + level;
                e.hp -= dmg;
                if (poisonStacks > 0) { e.hp -= 6; poisonStacks--; }
                game.quest.addMessage("Rogue stabs for " + dmg);
            }
        }
    }

    private void melee() {
        for (Enemy e : game.enemies) {
            int dx = Math.abs((e.x + e.width/2) - (x + width/2));
            int dy = Math.abs((e.y + e.height/2) - (y + height/2));
            if (dx <= 48 && dy <= 48) {
                e.hp -= baseDamage + level;
                game.quest.addMessage("Rogue hits for " + (baseDamage + level));
            }
        }
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(new Color(60,180,60));
        g.fillRect(x, y, width, height);
    }

    @Override
    protected int getAttackCost() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    protected int getSkillCost() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
