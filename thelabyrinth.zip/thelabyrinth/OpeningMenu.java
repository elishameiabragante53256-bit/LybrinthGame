/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thelabyrinth;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.GlyphVector;
import java.io.File;

public class OpeningMenu extends JPanel {

    private GameWindow window;

    // Textures
    private Image backgroundImage;
    private Image metalPlate;
    private Image metalButton;

    // Card panels
    private JPanel mainMenuPanel;
    private JPanel characterPanel;

    public OpeningMenu(GameWindow w) {
        this.window = w;

        // Load textures
        backgroundImage = new ImageIcon("background.png").getImage();
        metalPlate = new ImageIcon("title_plate.png").getImage();
        metalButton = new ImageIcon("metal_button.png").getImage();

        setLayout(new CardLayout());

        mainMenuPanel = buildMainMenu();
        characterPanel = buildCharacterSelect();

        add(mainMenuPanel, "MAIN");
        add(characterPanel, "CHAR_SELECT");
    }

    // ---------------------------------------------------------
    // MAIN MENU SCREEN WITH COMPLETE DESIGN
    // ---------------------------------------------------------
    private JPanel buildMainMenu() {

        JPanel p = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), null);
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(new Color(0, 0, 0, 120));
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        p.setOpaque(false);

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;

        // TITLE (metal plate, engraved, glowing)
        c.gridy = 0;
        JLabel title = engravedTitle("Welcome To The Labyrinth");
        title.setPreferredSize(new Dimension(700, 120));
        p.add(title, c);

        // BUTTON PANEL
        c.gridy = 1;
        JPanel buttons = new JPanel(new GridLayout(3, 1, 0, 8));
        buttons.setOpaque(false);
        buttons.setPreferredSize(new Dimension(220, 160));

        JButton start = metalButton("Start Game");
        start.addActionListener(e -> showCharacterSelect());

        JButton controls = metalButton("Controls");
        controls.addActionListener(e -> showControls());

        JButton exit = metalButton("Exit");
        exit.addActionListener(e -> System.exit(0));

        buttons.add(start);
        buttons.add(controls);
        buttons.add(exit);

        p.add(buttons, c);

        return p;
    }

    // ---------------------------------------------------------
    // CHARACTER SELECT SCREEN WITH SAME BACKGROUND & DESIGN
    // ---------------------------------------------------------
    private JPanel buildCharacterSelect() {

        JPanel p = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), null);
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(new Color(0, 0, 0, 120));
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        p.setOpaque(false);

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;

        c.gridy = 0;
        JLabel title = engravedTitle("Select Character");
        title.setPreferredSize(new Dimension(600, 100));
        p.add(title, c);

        // Character Buttons
        c.gridy = 1;
        JButton wBtn = metalButton("Warrior");
        wBtn.addActionListener(e -> window.startGame(Player.ClassType.WARRIOR));
        p.add(wBtn, c);

        c.gridy = 2;
        JButton rBtn = metalButton("Rogue");
        rBtn.addActionListener(e -> window.startGame(Player.ClassType.ROGUE));
        p.add(rBtn, c);

        c.gridy = 3;
        JButton mBtn = metalButton("Mage");
        mBtn.addActionListener(e -> window.startGame(Player.ClassType.MAGE));
        p.add(mBtn, c);

        // Back
        c.gridy = 4;
        JButton back = metalButton("Back");
        back.addActionListener(e -> showMainMenu());
        p.add(back, c);

        return p;
    }

    // ---------------------------------------------------------
    // ENGRAVED TITLE (reused for both screens)
    // ---------------------------------------------------------
    private JLabel engravedTitle(String text) {
        return new JLabel(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                g2.drawImage(metalPlate, 0, 0, getWidth(), getHeight(), null);

                String t = getText();
                Font f;

                try {
                    f = Font.createFont(Font.TRUETYPE_FONT, new File("JungleAdventure.ttf"))
                            .deriveFont(50f);
                } catch (Exception e) {
                    f = new Font("Serif", Font.BOLD, 50);
                }

                g2.setFont(f);
                FontMetrics fm = g2.getFontMetrics();

                int x = (getWidth() - fm.stringWidth(t)) / 2;
                int y = (getHeight() + fm.getAscent()) / 2 - 5;

                // Glow
                g2.setColor(new Color(255, 160, 40, 160));
                g2.drawString(t, x + 3, y + 3);

                // Main text
                g2.setColor(new Color(230, 170, 70));
                g2.drawString(t, x, y);

                // Engraved outline
                GlyphVector gv = f.createGlyphVector(g2.getFontRenderContext(), t);
                Shape outline = gv.getOutline(x, y);
                g2.setColor(new Color(70, 40, 10));
                g2.setStroke(new BasicStroke(3));
                g2.draw(outline);

                g2.dispose();
            }
        };
    }

    // ---------------------------------------------------------
    // METAL BUTTON (exact same style as your first menu)
    // ---------------------------------------------------------
    private JButton metalButton(String text) {
        JButton b = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                g2.drawImage(metalButton, 0, 0, getWidth(), getHeight(), null);

                // Gradient highlight
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(180, 80, 20),
                        0, getHeight(), new Color(240, 150, 40)
                );
                g2.setPaint(gp);
                g2.fillRoundRect(12, 10, getWidth() - 20, getHeight() - 15, 10, 10);

                // Border
                g2.setColor(new Color(255, 180, 80));
                g2.setStroke(new BasicStroke(3));
                g2.drawRoundRect(12, 10, getWidth() - 20, getHeight() - 15, 10, 10);

                // Text
                g2.setFont(new Font("Serif", Font.BOLD, 24));
                g2.setColor(Color.WHITE);
                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
                g2.drawString(getText(), x, y);

                g2.dispose();
            }
        };

        b.setPreferredSize(new Dimension(220, 50));
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setOpaque(false);

        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { b.setForeground(new Color(255, 240, 180)); }
            @Override public void mouseExited(MouseEvent e) { b.setForeground(Color.WHITE); }
        });

        return b;
    }

    // ---------------------------------------------------------
    // SHOW CONTROLS POPUP (same style as previous)
    // ---------------------------------------------------------
    private void showControls() {
        JOptionPane.showMessageDialog(
                this,
                """
                Controls:
                W A S D – Move
                SPACE – Attack
                1 / 2 – Skills
                Q – Health Potion
                E – Resource Potion
                R – Throw Weapon
                F – Interact
                """,
                "Controls",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    // ---------------------------------------------------------
    // CARD SWITCHING
    // ---------------------------------------------------------
    private void showCharacterSelect() {
        ((CardLayout) getLayout()).show(this, "CHAR_SELECT");
    }

    private void showMainMenu() {
        ((CardLayout) getLayout()).show(this, "MAIN");
    }
}
